#!/bin/bash
#/ Usage: release-helper.sh [-hdc] <version>
#/
#/ Creates a temporary branch from which a new release will be tagged and pushed.
#/
#/ OPTIONS:
#/   -h | --help        Show this message.
#/   -d | --delete      Delete a tag / release
#/   -c | --check       Check current releases on GitHub
#/   <version>          Target Cachet Version (ex: v2.3.13)
#/
set -e

usage () {
    grep "^#/" <"$0" | cut -c4-
    exit "${1:-2}"
}

[ $# -eq 0 ] && usage 1

cachet_version=
main_version=2.4

do_release () {

# Make sure we are on clean branch
if [[ ! $(git branch --list cachet-"$cachet_version") ]]; then
  echo "Creating new branch cachet-$cachet_version"
  git checkout -b cachet-"$cachet_version"
else
  echo "Branch cachet-$cachet_version already exists!"
  git checkout cachet-"$cachet_version"
fi

# Generate changelog (requires https://github.com/skywinder/github-changelog-generator)
if hash github_changelog_generator 2>/dev/null; then
  github_changelog_generator -u CachetHQ --project Docker --token "$token" --future-release "$cachet_version"
fi

# Modify Dockerfile, commit, tag, and push
echo "Creating tag for $cachet_version"
gsed s/$main_version/"$cachet_version"/g -i Dockerfile
git commit -am "Cachet $cachet_version release"
git tag -a "$cachet_version" -m "Cachet Release $cachet_version"
git push origin cachet-"$cachet_version"
git push origin "$cachet_version"

# Create GitHub release
curl -H "Authorization: token $token" -s -H "Content-Type: application/json" -d '{"tag_name":"'"${cachet_version}"'","name":"'"${cachet_version}"'","body":"Cachet Release '"${cachet_version}"'","draft":false,"prerelease":false}' -X POST https://api.github.com/repos/CachetHQ/Docker/releases
}

check_releases () {
# Get latest releases
CACHET_APP_LATEST_REL=$(curl -H "Authorization: token $token" -s https://api.github.com/repos/cachethq/cachet/releases/latest | jq -r .name)
CACHET_DOCKER_LATEST_REL=$(curl -H "Authorization: token $token" -s https://api.github.com/repos/cachethq/docker/releases/latest | jq -r .name)

echo "Latest Cachet release: $CACHET_APP_LATEST_REL"
echo "Latest Docker release: $CACHET_DOCKER_LATEST_REL"

# Compare versions
if [ "$CACHET_APP_LATEST_REL" = "$CACHET_DOCKER_LATEST_REL" ]
  then
    echo "Releases on GitHub are up to date!"
  else 
    echo "Docker at "$CACHET_DOCKER_LATEST_REL" -- Releasing latest app release $CACHET_APP_LATEST_REL" 
    cachet_version="$CACHET_APP_LATEST_REL"
    do_release
fi

}

delete_release () {
    if [ -z "$cachet_version" ]; then
      echo 1>&2 "error: no version specified."
      exit 1
    fi
    echo "Removing release $cachet_version"
    release_id=$(curl -H "Authorization: token $token" -s -X GET https://api.github.com/repos/CachetHQ/Docker/releases/tags/"$cachet_version" | jq -r .id)
    curl -H "Authorization: token $token" -s -X DELETE https://api.github.com/repos/CachetHQ/Docker/releases/"$release_id" || true
    git tag -d "$cachet_version" || true
    git push origin :"$cachet_version" || true
    git branch -d cachet-"$cachet_version" || true
}

# GitHub API Token
token=${GITHUB_TOKEN}

if [ -z "$token" ]
  then
    echo 1>&2 "error: please set GITHUB_TOKEN in your local environment."
    exit 1
fi

# Parse args.
ARGS=$(getopt --name "$0" --long help,delete,check,update: --options hdcu: -- "$@") || {
  usage
  exit 2
}
eval set -- "$ARGS"

while [ $# -gt 0 ]; do
  shift
  case "$1" in
    -h|--help)
      usage
      exit 2
      ;;
    -d|--delete)
      cachet_version=$2
      delete_release
      exit 0
      ;;
    -c|--check)
      check_releases
      exit 0
      ;;
    -u|--update)
      cachet_version=$2
      echo "Updating to Cachet version: $2"
      do_release
      break
      exit 0
      ;;
    --)
      cachet_version=$2
      do_release
      shift
      break
      ;;
  esac
  shift
done

if [ -z "$cachet_version" ]; then
    echo 1>&2 "error: no version specified."
    exit 1
fi
